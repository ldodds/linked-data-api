$:.unshift File.join(File.dirname(__FILE__), "..", "lib")
require 'test/unit'
require 'linked-data-api'
require 'mocha'
require 'logger'

class ResourceTest < Test::Unit::TestCase
 
  API = <<-EOL
@prefix api: <http://www.example.org/linked-data-api/>.
@prefix template: <http://www.example.org/linked-data-api/templates/>.
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>.
@prefix test: <http://tests/>.
test:api a api:API;
  api:sparqlEndpoint <http://api.talis.test/services/sparql>.

test:res1 a api:Endpoint;
  api:partOf test:api;
  api:uri "/testing/1/2/3";
  api:view [
    a api:View;
    api:select "SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. }";  
  ];
  api:defaultTemplate [
    a api:Template;
    api:pattern "{ ?item rdfs:label ?label. }";
    rdfs:label "labels"
  ];
  api:template [
    a api:Template;
    api:pattern "{ ?item rdfs:label ?label. ?item ?p ?o. }";
    rdfs:label "label-and-relations"
  ].

test:res2 a api:Endpoint;
    api:partOf test:api;
    api:uri "/testing/bounded";
    api:view [
      a api:View;
      api:select "SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. }";  
    ];
    api:defaultTemplate [
      a template:ConciseBoundedDescription
    ].   
         
test:res3 a api:Endpoint;
    api:partOf test:api;
    api:uri "/testing/default_template";
    api:view [
      a api:View;
      api:select "SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. }";  
    ].

  test:res4 a api:Endpoint;
      api:partOf test:api;
      api:uri "/testing/schools";
      api:view [
        a api:View;
        api:type <http://www.example.org/ns/School>  
      ].
        
EOL
   
  API2 = <<-EOL
@prefix api: <http://www.example.org/linked-data-api/>.
@prefix template: <http://www.example.org/linked-data-api/templates/>.
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>.
@prefix test: <http://tests/>.
test:api2 a api:API;
  api:sparqlEndpoint <http://api.talis.test/services/sparql>;
  api:binding [ api:uri "http://xmlns.com/foaf/0.1/"; rdfs:label "foaf" ];
  api:binding [ api:uri "http://www.w3.org/2000/01/rdf-schema#"; rdfs:label "rdfs" ].
  
  test:res4 a api:Endpoint;
      api:partOf test:api2;
      api:uri "/testing/1/2/3";
      api:view [
          a api:View;
          api:select "SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. }";  
      ].      
EOL

  SELECT_RESOURCE_RESULTS = <<-EOL
  {  
   "head": {  "vars": [ "item" ]  } ,  
    
   "results": {    
        "bindings": [     
            {  "item": { "type": "uri" , "value": "http://www.example.org/school/1" }
            } ,     
           {   "item": { "type": "uri" , "value": "http://www.example.org/school/2" }
           }    
        ]  
    }
  }  
  EOL

  DESCRIBE_RESULTS_1 = <<-EOL
<rdf:RDF xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:ex="http://www.example.org/ns/">
<ex:School rdf:about="http://www.example.org/school/1">
<rdfs:label>School 1</rdfs:label>
</ex:School>
</rdf:RDF>
  EOL

  DESCRIBE_RESULTS_2 = <<-EOL
<rdf:RDF xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:ex="http://www.example.org/ns/">
<ex:School rdf:about="http://www.example.org/school/2">
<rdfs:label>School 2</rdfs:label>
</ex:School>
</rdf:RDF>
  EOL
  
  def setup()
    model = Redland::Model.new()
    parser = Redland::Parser.new("turtle", "", nil)
    parser.parse_string_into_model(model, API, "http://tests/")
    @api = model
    
    model = Redland::Model.new()
    parser = Redland::Parser.new("turtle", "", nil)
    parser.parse_string_into_model(model, API2, "http://tests/")
    @apitwo = model    
  end
  
  def teardown()
    @api = nil
  end    

  def test_view()
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")
    
    assert_not_nil( resource.view)   
    assert_equal("SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. }", resource.view.select) 
  end
  
  def test_default_template()
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")
    
    assert_not_nil( resource.default_template )   
    assert_equal("labels", resource.default_template.label )
    assert_equal("{ ?item rdfs:label ?label. }", resource.default_template.pattern ) 
  end
  
  def test_template_match()
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")

    template = resource.template("label-and-relations")
    assert_not_nil(template)
    assert_equal("label-and-relations", template.label )
    assert_equal("{ ?item rdfs:label ?label. ?item ?p ?o. }", template.pattern ) 
    
  end
  
  def test_template_failed_match_returns_default()
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")

    template = resource.template("unknown")
    assert_not_nil(template)
    assert_equal("labels", resource.default_template.label )     
  end
  
  def test_select_resources()     
     uri = "/testing/1/2/3"
     params = {}
     request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
     
     mc = mock()
     mc.expects(:select).with("SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. } ORDER BY ?item", Pho::Sparql::SPARQL_RESULTS_JSON).returns(
       HTTP::Message.new_response( SELECT_RESOURCE_RESULTS ) )

     api = LinkedDataAPI::API.from_model(@api)
     resource = api.resource_for_uri("/testing/1/2/3")
     uris = resource.select_resources(mc, request )
     assert_equal(2, uris.length)     
  end

  def test_select_resources_with_type_selection()
    uri = "/testing/schools"
    params = {}
    request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/schools", uri, params)
    
    mc = mock()
    mc.expects(:select).with("SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. } ORDER BY ?item", Pho::Sparql::SPARQL_RESULTS_JSON).returns(
      HTTP::Message.new_response( SELECT_RESOURCE_RESULTS ) )

    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/schools")
    uris = resource.select_resources(mc, request )
    assert_equal(2, uris.length)         
  end
  
  def test_select_resources_with_binding()     
     uri = "/testing/1/2/3"
     params = {}
     request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
     
     mc = mock()
     mc.expects(:select).with("PREFIX foaf: <http://xmlns.com/foaf/0.1/>\nPREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nSELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. } ORDER BY ?item", Pho::Sparql::SPARQL_RESULTS_JSON).returns(
       HTTP::Message.new_response( SELECT_RESOURCE_RESULTS ) )
  
     api = LinkedDataAPI::API.from_model(@apitwo)
     resource = api.resource_for_uri("/testing/1/2/3")
     uris = resource.select_resources(mc, request )
     assert_equal(2, uris.length)     
  end

       
  def test_select_resources_with_limit_offset()     
     uri = "/testing/1/2/3"
     params = {}
     params["limit"] = 10
     params["offset"] = 10
     request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
     
     mc = mock()
     mc.expects(:select).with("SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. } ORDER BY ?item LIMIT 10 OFFSET 10", Pho::Sparql::SPARQL_RESULTS_JSON).returns(
       HTTP::Message.new_response( SELECT_RESOURCE_RESULTS ) )
  
     api = LinkedDataAPI::API.from_model(@api)
     resource = api.resource_for_uri("/testing/1/2/3")
     uris = resource.select_resources(mc, request )
     assert_equal(2, uris.length)     
  end
  
  def test_describe_resource()
    uri = "/testing/1/2/3"
    params = {}
    request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
    
    mc = mock()
    mc.expects(:query).with("CONSTRUCT { <http://www.example.org/school/1/2/3> rdfs:label ?label. } WHERE { <http://www.example.org/school/1/2/3> rdfs:label ?label. }", "application/rdf+xml").returns( HTTP::Message.new_response( "OK" ) )
    
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")
    desc = resource.describe_resource(mc, request, "http://www.example.org/school/1/2/3")
    assert_equal("OK", desc)
  end

  def test_describe_resource_with_bounded_description()
    uri = "/testing/bounded"
    params = {}
    request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
    
    mc = mock()
    mc.expects(:query).with("DESCRIBE <http://www.example.org/school/1/2/3>", "application/rdf+xml").returns( HTTP::Message.new_response( "OK" ) )
    
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/bounded")
    desc = resource.describe_resource(mc, request, "http://www.example.org/school/1/2/3")
    assert_equal("OK", desc)
  end
  
  def test_describe_resource_with_defaulted_template()
    uri = "/testing/default_template"
    params = {}
    request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
    
    mc = mock()
    mc.expects(:query).with("DESCRIBE <http://www.example.org/school/1/2/3>", "application/rdf+xml").returns( HTTP::Message.new_response( "OK" ) )
    
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/default_template")
    desc = resource.describe_resource(mc, request, "http://www.example.org/school/1/2/3")
    assert_equal("OK", desc)
  end
    
  def test_describe_resource_with_detail()
    uri = "/testing/1/2/3"
    params = {}
    params["detail"] = "label-and-relations"
    request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)
    
    mc = mock()
    mc.expects(:query).with("CONSTRUCT { <http://www.example.org/school/1/2/3> rdfs:label ?label. <http://www.example.org/school/1/2/3> ?p ?o. } WHERE { <http://www.example.org/school/1/2/3> rdfs:label ?label. <http://www.example.org/school/1/2/3> ?p ?o. }", "application/rdf+xml").returns( HTTP::Message.new_response( "OK" ) )
    
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")
    desc = resource.describe_resource(mc, request, "http://www.example.org/school/1/2/3")
    assert_equal("OK", desc)
  end
    
  def test_apply
    uri = "/testing/1/2/3"
    params = {}
    request = LinkedDataAPI::Request.new("http://127.0.0.1/testing/1/2/3", uri, params)    
    mc = mock()
    mc.expects(:select).with("SELECT ?item WHERE { ?item a <http://www.example.org/ns/School>. } ORDER BY ?item", Pho::Sparql::SPARQL_RESULTS_JSON).returns(
      HTTP::Message.new_response( SELECT_RESOURCE_RESULTS ) )
    mc.expects(:endpoint).returns("http://www.example.org")
    mc.expects(:endpoint).returns("http://www.example.org")
    mc.expects(:query).with(
     "CONSTRUCT { <http://www.example.org/school/1> rdfs:label ?label. } WHERE { <http://www.example.org/school/1> rdfs:label ?label. }", "application/rdf+xml").returns( 
      HTTP::Message.new_response( DESCRIBE_RESULTS_1 ) )    
    mc.expects(:query).with(
    "CONSTRUCT { <http://www.example.org/school/2> rdfs:label ?label. } WHERE { <http://www.example.org/school/2> rdfs:label ?label. }", "application/rdf+xml").returns( 
      HTTP::Message.new_response( DESCRIBE_RESULTS_2 ) )
    mc.expects(:endpoint).returns("http://www.example.org")
      
    api = LinkedDataAPI::API.from_model(@api)
    resource = api.resource_for_uri("/testing/1/2/3")
    resp = resource.apply(mc, request)
    assert_equal("application/rdf+xml", resp.mimetype)
    assert_not_nil( resp.content )
    
    #puts resp.content  
  end
  
#  def test_list
#    api = LinkedDataAPI::API.from_model(@api)
#    resource = api.resource_for_uri("/testing/1/2/3")
#    res = resource.resource
#    puts res.get_property(LinkedDataAPI::Namespaces::API_RENDER).get_properties() do |o|
#      puts o
#    end    
#  end    
end