$:.unshift File.dirname(__FILE__)
require 'test/unit'

require 'tc_api.rb'
require 'tc_resource.rb'
require 'tc_view.rb'
require 'tc_urlmatcher.rb'