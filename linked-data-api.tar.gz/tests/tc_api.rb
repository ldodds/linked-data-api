$:.unshift File.join(File.dirname(__FILE__), "..", "lib")
require 'test/unit'
require 'linked-data-api'

class APITest < Test::Unit::TestCase
  
  API = <<-EOL
@prefix api: <http://www.example.org/linked-data-api/>.
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>.
@prefix test: <http://tests/>.
test:api a api:API;
  api:sparqlEndpoint <http://api.talis.test/services/sparql>;
  api:binding [ api:uri "http://xmlns.com/foaf/0.1/name"; rdfs:label "foaf" ];
  api:binding [ api:uri "http://www.w3.org/2000/01/rdf-schema#"; rdfs:label "rdfs" ].

test:res1 a api:Endpoint;
  api:partOf test:api;
  api:uri "/testing/1/2/3".
  
test:res2 a api:Endpoint;
  api:partOf test:api;
  api:uri "/testing/a/b/c".
  
test:res3 a api:Endpoint;
  api:partOf test:api;
  api:uriTemplate "/testing?start={x}".     
  
test:res4 a api:Endpoint;
  api:partOf test:api;
  api:uriTemplate "/testing?end={y}&start={x}".     
EOL

  def setup()
    model = Redland::Model.new()
    parser = Redland::Parser.new("turtle", "", nil)
    parser.parse_string_into_model(model, API, "http://tests/")
    @api = model
  end
  
  def teardown()
    @api = nil
  end    
  
  def test_create_from_model
    api = LinkedDataAPI::API.from_model(@api)
    assert_not_nil(api)
    assert_equal("http://tests/api", api.resource_uri)
    resources = api.resources
    assert_equal(4, resources.length)
  end

  def test_match_uri
    api = LinkedDataAPI::API.from_model(@api)
    assert_equal(true, api.resource_for_uri?("/testing/1/2/3") )
    assert_equal(false, api.resource_for_uri?("/not/found"))     
  end
  
  def test_match_uri_to_resource
    api = LinkedDataAPI::API.from_model(@api)
    res = api.resource_for_uri("/testing/1/2/3")
    assert_not_nil(res)
    assert_equal("http://tests/res1", res.resource_uri)    
  end
  
  def test_match_uri_to_resource_with_template
    api = LinkedDataAPI::API.from_model(@api)
    res = api.resource_for_uri("/testing")
    assert_nil(res)
    res = api.resource_for_uri("/testing", {"end"=>"123"})
    assert_nil(res)
    res = api.resource_for_uri("/testing", {"start"=>"123", "end"=>"456"})
    assert_not_nil(res)
    assert_equal("http://tests/res4", res.resource_uri)    
    res = api.resource_for_uri("/testing", {"start"=>"123"})
    assert_not_nil(res)
    assert_equal("http://tests/res3", res.resource_uri)          
  end
  
  def test_endpoint
    api = LinkedDataAPI::API.from_model(@api)
    sparql_endpoint = api.endpoint
    assert_equal("http://api.talis.test/services/sparql", sparql_endpoint)
  end
  
  def test_bindings
    api = LinkedDataAPI::API.from_model(@api)
    bindings = api.bindings
    assert_not_nil(bindings)
    assert_equal(2, bindings.length)   
  end
  
end