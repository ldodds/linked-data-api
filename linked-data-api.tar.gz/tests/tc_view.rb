$:.unshift File.join(File.dirname(__FILE__), "..", "lib")
require 'test/unit'
require 'linked-data-api'
require 'mocha'
require 'logger'

class ViewTest < Test::Unit::TestCase
  
  VIEWS = <<-EOL
@prefix api: <http://www.example.org/linked-data-api/>.
@prefix test: <http://tests/>.

test:simple
  api:select "SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. }".

test:with_default_limit
    api:select "SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. }";
    api:defaultLimit "10".
             
EOL
  
  def setup()
    model = Redland::Model.new()
    parser = Redland::Parser.new("turtle", "", nil)
    parser.parse_string_into_model(model, VIEWS, "http://tests/")
    @views = model
    @request = LinkedDataAPI::Request.new("http://tests/api", "/api", {})
  end
  
  def teardown()
    @views = nil
  end  
  
  def test_resource_query()
    resource = @views.get_resource("http://tests/simple")
    assert_not_nil(resource)
    view = LinkedDataAPI::View.new( resource )
    assert_equal("SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. } ORDER BY ?item", view.resource_query(@request) )
  end  
  
  def test_resource_query_with_default_limit()
    resource = @views.get_resource("http://tests/with_default_limit")
    assert_not_nil(resource)
    view = LinkedDataAPI::View.new( resource )
    assert_equal("SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. } ORDER BY ?item LIMIT 10", view.resource_query(@request) )
  end

  def test_resource_query_with_default_limit_and_offset()
    resource = @views.get_resource("http://tests/with_default_limit")
    assert_not_nil(resource)
    @request.params["offset"] = 10
    view = LinkedDataAPI::View.new( resource )
    assert_equal("SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. } ORDER BY ?item LIMIT 10 OFFSET 10", view.resource_query(@request) )
  end
    
  def test_resource_query_with_limit_in_request()
    resource = @views.get_resource("http://tests/simple")
    @request.params["limit"] = 5
    assert_not_nil(resource)
    view = LinkedDataAPI::View.new( resource )
    assert_equal("SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. } ORDER BY ?item LIMIT 5", view.resource_query(@request) )
  end
  
  def test_resource_query_with_offset()
    resource = @views.get_resource("http://tests/simple")
    @request.params["offset"] = 5
    assert_not_nil(resource)
    view = LinkedDataAPI::View.new( resource )
    assert_equal("SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. } ORDER BY ?item OFFSET 5", view.resource_query(@request) )
  end

  def test_resource_query_with_limit_and_offset()
    resource = @views.get_resource("http://tests/simple")
    @request.params["offset"] = 5
    @request.params["limit"] = 5
    assert_not_nil(resource)
    view = LinkedDataAPI::View.new( resource )
    assert_equal("SELECT ?item WHERE { ?item a <http://purl.org/net/schemas/space/Discipline>. } ORDER BY ?item LIMIT 5 OFFSET 5", view.resource_query(@request) )
  end
        
end
