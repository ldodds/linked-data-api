require 'rubygems'
require 'httpclient'
require 'json'
require 'rdf/redland'
require 'pho'
require 'uuid'

require 'linked-data-api/Util'
require 'linked-data-api/Base'
require 'linked-data-api/Resource'
require 'linked-data-api/API'
require 'linked-data-api/Request'
require 'linked-data-api/Response'
require 'linked-data-api/URLMatcher'

module LinkedDataAPI
  
  class Namespaces

    OWLNS = Redland::Namespace.new("http://www.w3.org/2002/07/owl#")    
    RDFS = Redland::Namespace.new("http://www.w3.org/2000/01/rdf-schema#")
    RDF = Redland::Namespace.new("http://www.w3.org/1999/02/22-rdf-syntax-ns#")
    
    RDFS_CLASS = RDFS["Class"]
    RDFS_LABEL = RDFS["label"]
    
    RDF_TYPE = RDF["type"]
    RDF_SEQ = RDF["Seq"]
        
    DCTERMS = Redland::Namespace.new("http://purl.org/dc/terms/")
    DCTERMS_TITLE = DCTERMS["title"]
    DCTERMS_CREATED = DCTERMS["created"]
    DCTERMS_MODIFIED = DCTERMS["modified"]
    DCTERMS_DESCRIPTION = DCTERMS["description"]
    
    API = Redland::Namespace.new("http://www.example.org/linked-data-api/")
       
    API_URI = API["uri"]
    API_URI_TEMPLATE = API["uriTemplate"]
    
    API_SPARQL_ENDPOINT = API["sparqlEndpoint"]
    
    API_VIEW = API["view"]
    API_DEFAULT_TEMPLATE = API["defaultTemplate"]
    API_TEMPLATE = API["template"]
    API_RENDER = API["render"]
    
    API_WHERE = API["where"]
    API_PATTERN = API["pattern"]
    API_SELECT = API["select"]
    API_ORDER_BY = API["orderBy"]
            
    API_API = API["API"]
    API_ENDPOINT = API["Endpoint"]
    
    API_PART_OF = API["partOf"]
    
    TEMPLATE = Redland::Namespace.new("http://www.example.org/linked-data-api/templates/")
    
    TEMPLATE_CBD = TEMPLATE["ConciseBoundedDescription"]
    TEMPLATE_LCBD = TEMPLATE["LabelledConciseBoundedDescription"]

    API_DEFAULT_LIMIT = API["defaultLimit"]

    API_BINDING = API["binding"]    
    
    API_RESULTS = API["results"]
    API_TYPE = API["type"]
                
  end
  
  
end
