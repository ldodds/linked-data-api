module LinkedDataAPI
  
  class View
  
    attr_reader :resource
        
    def initialize(resource)
        @resource = resource  
    end  
    
    def select()
      return Util.get_literal(@resource, LinkedDataAPI::Namespaces::API_SELECT)
    end

    def default_limit()
      return Util.get_literal(@resource, LinkedDataAPI::Namespaces::API_DEFAULT_LIMIT)
    end
    
    def select_type()
      return @resource.get_property(LinkedDataAPI::Namespaces::API_TYPE)
    end
    
    def order_by()
      return Util.get_literal(@resource, LinkedDataAPI::Namespaces::API_ORDER_BY)
    end
                
    def resource_query(request)
      #TODO other options than just select and type query?
      query = select()
      if query == nil && nil != select_type()
        query = "SELECT ?item WHERE { ?item a <#{select_type().uri.to_s}>. }"
      end

      #TODO allow order by in URL?
      if order_by() != nil
        #FIXME assuming here the value of the property is a variable name, but is it?
        query = query + " ORDER BY #{order_by()}"
      else
        query = query + " ORDER BY ?item"  
      end
                   
      if request.limit?
        query = query + " LIMIT #{request.limit()}"
      end
      if default_limit() != nil && !request.limit?
        query = query + " LIMIT #{default_limit()}"
      end
      if request.offset?
        query = query + " OFFSET #{request.offset()}"
      end      
      return query
    end
            
  end
  
  class Template
    
    #Obviously assuming this is the default!
    CONCISE_BOUNDED_DESCRIPTION = "DESCRIBE ?item"
    
    LABELLED_BOUNDED_DESCRIPTION = <<-EOL
    CONSTRUCT {
       ?item ?p ?o . 
       ?o <http://www.w3.org/2000/01/rdf-schema#label> ?label . 
       ?o rdfs:comment ?comment . 
       ?o <http://www.w3.org/2004/02/skos/core#prefLabel> ?plabel . 
       ?o <http://www.w3.org/2000/01/rdf-schema#seeAlso> ?seealso.
    } WHERE {
      ?item ?p ?o . 
      OPTIONAL { 
        ?o rdfs:label ?label .
      } 
      OPTIONAL {
        ?o <http://www.w3.org/2004/02/skos/core#prefLabel> ?plabel . 
      } 
      OPTIONAL {
        ?o <http://www.w3.org/2000/01/rdf-schema#comment> ?comment . 
      } 
      OPTIONAL { 
        ?o <http://www.w3.org/2000/01/rdf-schema#seeAlso> ?seealso.
      }
    }    
    EOL
        
    attr_reader :resource
        
    def initialize(resource)
        @resource = resource  
    end  
    
    def label()
      return Util.get_literal(@resource, LinkedDataAPI::Namespaces::RDFS_LABEL)
    end
    
    def pattern()
      return Util.get_literal(@resource, LinkedDataAPI::Namespaces::API_PATTERN)
    end
        
    def create_query()
      #HACK add factory method for constructing proper templates
      if nil == @resource
        return CONCISE_BOUNDED_DESCRIPTION
      end
      type = @resource.get_property(LinkedDataAPI::Namespaces::RDF_TYPE).uri.to_s
      if type == LinkedDataAPI::Namespaces::TEMPLATE_CBD.uri.to_s
        return CONCISE_BOUNDED_DESCRIPTION
      end
      if type == LinkedDataAPI::Namespaces::TEMPLATE_LCBD.uri.to_s
        return LABELLED_BOUNDED_DESCRIPTION 
      end      
      if pattern() != nil
        return "CONSTRUCT #{pattern()} WHERE #{pattern()}"
      end
      return CONCISE_BOUNDED_DESCRIPTION
    end
    
  end
  
  class Resource < Base
    
       
    attr_reader :view
    attr_reader :default_template
    attr_reader :templates
    attr_reader :api
        
    def initialize(resource, api)
        super(resource)  
        @api = api
        @view = View.new( @resource.get_property(LinkedDataAPI::Namespaces::API_VIEW) )
        @default_template = Template.new( @resource.get_property(LinkedDataAPI::Namespaces::API_DEFAULT_TEMPLATE) )
        
        @templates = []
        @resource.get_properties(LinkedDataAPI::Namespaces::API_TEMPLATE) do |obj|
          @templates << Template.new(obj)
        end
        
    end

    def uri
        return get_literal(LinkedDataAPI::Namespaces::API_URI)  
    end

    def uri_template
        return get_literal(LinkedDataAPI::Namespaces::API_URI_TEMPLATE)  
    end
    
    def uri_template?
      return uri_template() != nil
    end

    def template(name)
      if name == nil
        return @default_template
      end
      @templates.each do |template|
        if template.label.eql?(name)
          return template
        end
      end
      return @default_template
    end

    def apply(sparql_client, request)      
      #fetch list using view query
      resources = select_resources(sparql_client, request)
      #puts "fetched #{resources.length} uris"
      model = Redland::Model.new()
    
      build_result_list(model, request, resources)        
      
      #for each item in the list, do a query based on the appropriate template
      resources.each do |resource|
        desc = describe_resource(sparql_client, request, resource)
        #build an RDF model and add statements from template
        parser = Redland::Parser.new()
        parser.parse_string_into_model(model, desc, sparql_client.endpoint)
      end
                  
      #TODO select the renderer
      
      #serialize model 
      serializer = Redland::Serializer.new("rdfxml-abbrev")
      configure_serializer(serializer)
      data = serializer.model_to_string(Redland::Uri.new(sparql_client.endpoint), model)      
      
      #TODO right mimetype, etc
      return Response.new("application/rdf+xml", data)
      
    end
    
    #return an array of resources
    def select_resources(sparql_client, request)      
      query = @view.resource_query(request)
      bound_query = Pho::Sparql::SparqlHelper.apply_initial_bindings(query, request.params)
      bound_query = add_prefix_bindings(bound_query)
      puts bound_query
      uris = Pho::Sparql::SparqlHelper.select_values(bound_query, sparql_client)
      return uris
    end
    
    def describe_resource(sparql_client, request, uri)
      puts "Describing #{uri}"
      template = template( request.detail )
      construct_query = template.create_query
      vars = request.params
      vars["item"] = "<#{uri}>"
      bound_query = Pho::Sparql::SparqlHelper.apply_initial_bindings(construct_query, vars)
      bound_query = add_prefix_bindings(bound_query)
      #puts uri
      resp = sparql_client.query(bound_query, "application/rdf+xml")
      if resp.status != 200
        raise "Error performing sparql query: #{resp.status} #{resp.reason}\n#{resp.content}"
      end
      #puts "done"            
      return resp.content
      
    end 
    
    def add_prefix_bindings(query)      
      return @api.bindings_to_prefix + query  
    end

    def configure_serializer(serializer)
      #TODO extract these
      serializer.set_namespace("api", "http://www.example.org/linked-data-api/")
      serializer.set_namespace("rdfs", "http://www.w3.org/2000/01/rdf-schema#")
      serializer.set_namespace("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#")
            
      @api.bindings.each do |binding|
        serializer.set_namespace(binding[0], binding[1])
      end      
    end
    
    def build_result_list(model, request, resources)
      result = model.create_resource()
      model.add(model.create_resource(request.uri), 
        LinkedDataAPI::Namespaces::API_RESULTS, 
        result)
      
      #TODO sort out whether there's an intermediary resource
      model.add(result, 
        LinkedDataAPI::Namespaces::RDF_TYPE,
        LinkedDataAPI::Namespaces::RDF_SEQ)
                      
      resources.each_with_index do |resource, index|
        model.add(result, 
          model.create_resource("http://www.w3.org/1999/02/22-rdf-syntax-ns\#li"), 
          model.create_resource(resource))
      end
              
    end    
  end
    
end
