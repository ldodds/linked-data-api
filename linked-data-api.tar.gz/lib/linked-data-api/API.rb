module LinkedDataAPI
  
  class API < Base
  
    attr_reader :resources
    attr_reader :endpoint
    attr_reader :bindings
    
    def initialize(resource, model)
        super(resource)
        @model = model
        @resources = []
        @model.find(nil, LinkedDataAPI::Namespaces::API_PART_OF, @resource) do |s,p,o|
          @resources << Resource.new(s, self)
        end
        @endpoint = @resource.get_property(LinkedDataAPI::Namespaces::API_SPARQL_ENDPOINT).uri.to_s
        
        @bindings = {}
        @resource.get_properties(LinkedDataAPI::Namespaces::API_BINDING) do |o|
          prefix = o.get_property(LinkedDataAPI::Namespaces::API_URI)
          label =  Util.get_literal( o, LinkedDataAPI::Namespaces::RDFS_LABEL)
          if nil != prefix and nil != label
            @bindings[label] = prefix.value
          end
        end
    end

    #Create API from Redland Model
    #TODO specify uri?
    def API.from_model(model)      
      api = model.subject(Redland::TYPE, LinkedDataAPI::Namespaces::API_API)
      return API.new(api, model)
    end
    
    #Create API from file
    def API.from_file(file=nil, format="turtle", mimetype="", base=nil)
      if file == nil
        raise "Filename should be provided"
      end
      
      model = Redland::Model.new()
      parser = Redland::Parser.new(format, mimetype, base)
      parser.parse_into_model(model,"file:#{file}")
      
      return API.from_model(model)
    end
    
    def resource_for_uri?(uri_path, params={})
      return true if resource_for_uri(uri_path) != nil
      return false
    end
    
    #TODO: template matching
    def resource_for_uri(uri_path, params={})
      @resources.each do |r|
        if r.uri == uri_path
          return r
        end        
      end
      puts "Checking templates"
      @resources.each do |r|
        if r.uri_template != nil && 
          LinkedDataAPI::URLMatcher.match?(uri_path, r.uri_template, params, LinkedDataAPI::Request::RESERVED_PARAMS)
          return r
        end
      end
      #TODO default resource?
      puts "No resource"
      return nil
    end
    
    def apply(request)
      #FIXME what if not found?      
      puts request.params.inspect
      res = resource_for_uri( request.path, request.params )
      sparql_client = Pho::Sparql::SparqlClient.new(@endpoint)
      return res.apply(sparql_client, request)           
    end
    
    def bindings_to_prefix
      prefix = ""
      @bindings.sort.each do |binding|
        prefix = prefix + "PREFIX #{binding[0]}: <#{binding[1]}>\n"
      end
      return prefix  
    end
    
  end
  
end