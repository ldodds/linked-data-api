module LinkedDataAPI
  
  module Util
    
    def Util.get_literal(resource, property)
      object = resource.get_property(property)
      if object
        return object.value
      end  
      return nil      
    end
        
  end
  
end