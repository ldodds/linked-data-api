module LinkedDataAPI

  class Request
    
    attr_reader :uri
    attr_reader :path
    attr_reader :params
    
    ORDER = "order"
    LIMIT = "limit"
    OFFSET = "offset"
    DETAIL = "detail"

    RESERVED_PARAMS = [
      ORDER, LIMIT, OFFSET, DETAIL
    ]

    def initialize(uri, path, params)
      @uri = uri
      @path = path
      @params = params
    end
    
    def order?()
      return @params[ORDER] != nil
    end
    
    def order
      return @params[ORDER].split(",")
    end
    
    def limit?()
      return @params[LIMIT] != nil
    end
    
    def limit()
      return @params[LIMIT]
    end
    
    def offset?()
      return @params[OFFSET] != nil
    end
    
    def offset()
      return @params[OFFSET]
    end
    
    def detail()
      return @params[DETAIL]
    end
    
  end
  
  
end