module LinkedDataAPI
  
  class Base
      attr_reader :resource
      
      def initialize(resource)
        @resource = resource
      end
      
      def resource_uri()
          return @resource.uri.to_s  
      end
      
      def get_literal(property)
        return Util.get_literal(@resource, property)   
      end

      def label()
        return get_literal(LinkedDataAPI::Namespaces::RDFS_LABEL)
      end    
      def comment()
        return get_literal(LinkedDataAPI::Namespaces::RDFS_COMMENT)
      end
      def description()
        return get_literal(LinkedDataAPI::Namespaces::DCTERMS_DESCRIPTION)
      end
            
  end
  
end