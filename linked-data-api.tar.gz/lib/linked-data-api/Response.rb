module LinkedDataAPI

    class Response
      attr_reader :mimetype, :content
      def initialize(mimetype, content)
        @mimetype = mimetype
        @content = content
      end
    end
    
end